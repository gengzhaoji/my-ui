import{_ as s,c as n,o as a,a as e}from"./app.7dede5df.js";const h=JSON.parse('{"title":"\u4E91\u684C\u9762\u5F00\u53D1\u76F8\u5173\u5730\u5740","description":"","frontmatter":{},"headers":[{"level":2,"title":"\u4E91\u684C\u9762\u5F00\u53D1\u76F8\u5173\u5730\u5740","slug":"\u4E91\u684C\u9762\u5F00\u53D1\u76F8\u5173\u5730\u5740"}],"relativePath":"new/address.md","lastUpdated":1680507934000}'),p={name:"new/address.md"},l=e(`<h2 id="\u4E91\u684C\u9762\u5F00\u53D1\u76F8\u5173\u5730\u5740" tabindex="-1">\u4E91\u684C\u9762\u5F00\u53D1\u76F8\u5173\u5730\u5740 <a class="header-anchor" href="#\u4E91\u684C\u9762\u5F00\u53D1\u76F8\u5173\u5730\u5740" aria-hidden="true">#</a></h2><div class="language-"><span class="copy"></span><pre><code><span class="line"><span style="color:#A6ACCD;">\u5916\u90E8\u5171\u4EAB\u76EE\u5F55: \\\\172.16.30.31 ftp/ftp</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">\u4ED3\u5E93(git)\uFF1A http://172.16.12.216:9980/</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">\u4E91\u76D8(Seafile)\uFF1A http://172.16.12.216:9021/</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">\u6587\u6863(wiki)\uFF1A http://172.16.12.216:8090/</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">\u63A5\u53E3(Yapi)\uFF1Ahttp://172.16.12.216:3000/</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">\u7985\u9053(Zentao)\uFF1Ahttp://172.16.12.216:8070/</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">\u81EA\u52A8\u5316(Jenkins)\uFF1Ahttp://172.16.12.216:8082/login     jenkins   /     RundOwJenkins@0226</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span></code></pre></div>`,2),t=[l];function o(c,r,i,A,d,C){return a(),n("div",null,t)}var D=s(p,[["render",o]]);export{h as __pageData,D as default};
