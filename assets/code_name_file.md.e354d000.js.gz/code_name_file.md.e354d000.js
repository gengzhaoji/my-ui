import{_ as s,c as a,o as n,a as e}from"./app.7dede5df.js";const m=JSON.parse('{"title":"","description":"","frontmatter":{},"headers":[],"relativePath":"code/name/file.md","lastUpdated":1678083950000}'),l={name:"code/name/file.md"},p=e(`<p>\u786E\u4FDD\u6587\u4EF6\u547D\u540D\u603B\u662F\u4EE5\u5B57\u6BCD\u5F00\u5934\u800C\u4E0D\u662F\u6570\u5B57\uFF0C\u4E14\u5B57\u6BCD\u4E00\u5F8B\u5C0F\u5199\uFF0C\u4EE5\u4E0B\u5212\u7EBF\u8FDE\u63A5\u4E14\u4E0D\u5E26\u5176\u4ED6\u6807\u70B9\u7B26\u53F7\uFF0C\u5982\uFF1A</p><div class="language-"><span class="copy"></span><pre><code><span class="line"><span style="color:#A6ACCD;">&lt;!-- HTML --&gt;</span></span>
<span class="line"><span style="color:#A6ACCD;">rdc.html</span></span>
<span class="line"><span style="color:#A6ACCD;">rdc_list.html</span></span>
<span class="line"><span style="color:#A6ACCD;">rdc_detail.html</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span>
<span class="line"><span style="color:#A6ACCD;">&lt;!-- SASS --&gt;</span></span>
<span class="line"><span style="color:#A6ACCD;">rdc.scss</span></span>
<span class="line"><span style="color:#A6ACCD;">rdc_list.scss</span></span>
<span class="line"><span style="color:#A6ACCD;">rdc_detail.scss</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span></code></pre></div>`,2),c=[p];function t(o,r,i,_,d,A){return n(),a("div",null,c)}var D=s(l,[["render",t]]);export{m as __pageData,D as default};
